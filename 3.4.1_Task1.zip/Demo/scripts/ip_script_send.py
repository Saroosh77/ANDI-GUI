from time import sleep

custom_mac = "6C:3C:8C:12:0D:17"


ipv4_msg_1.ethernet_header.mac_address_source = custom_mac
ipv4_msg_1.ethernet_header.mac_address_destination = Logging.get_mac()

ipv4_msg_1.payload = System.Array[Byte](bytearray.fromhex("01 02 03 04 09"))


ipv4_msg_1.send()


