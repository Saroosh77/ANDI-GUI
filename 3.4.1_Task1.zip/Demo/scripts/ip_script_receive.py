from time import sleep

def on_eth_msg_received(msg):
        print("Received following message from {0}".format(msg))


ipv4_msg_1.on_message_received += on_eth_msg_received


ipv4_msg_1.start_capture()

sleep(15)


ipv4_msg_1.stop_capture()

ipv4_msg_1.on_message_received -= on_eth_msg_received