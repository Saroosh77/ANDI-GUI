# --- Imports

from globals import *

clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")

from System.Windows.Forms import Application, Form, TableLayoutPanel, Button, DockStyle, MessageBox
from System.Drawing import Color
from time import sleep


# --- Functions


class GUI_Dialog(Form):


        def __init__(self, width, height):

                self.Text = "GUI MENU"
                self.Width = width
                self.Height = height


                l_tbl_content_panel = TableLayoutPanel()
                l_tbl_content_panel.AutoSize = True
                l_tbl_content_panel.Dock = DockStyle.Fill
                l_tbl_content_panel.AutoScroll = True

                self.panel_right = TableLayoutPanel()
                self.panel_right.Dock = DockStyle.Fill
                self.panel_right.BackColor = Color.LightGray

                self.btn_iCAM = self.create_button("Send", self.on_click_btn_send)
                self.btn_satCam = self.create_button("Show Message", self.on_click_btn_show_message)
                self.btn_satCam = self.create_button("Receive", self.on_click_btn_receive)

                l_tbl_content_panel.Controls.Add(self.panel_right, 0,0)

                self.Controls.Add(l_tbl_content_panel)
                self.CenterToScreen()


        def create_button(self, name, listener):
                btn = Button()
                btn.Click += listener
                btn.Text = name
                btn.Parent = self.panel_right
                btn.Width = 160
                btn.Height = 35
                return btn

        def on_click_btn_send(self, sender, args):
                custom_mac = "6C:3C:8C:12:0D:17"
                ethernet_msg_1.mac_address_source = custom_mac
                ethernet_msg_1.mac_address_destination = Logging.get_mac()

                ethernet_msg_1.payload = System.Array[Byte](bytearray.fromhex("01 02 03 04 09"))

                while(True):
    
                    ethernet_msg_1.send()
                    sleep(10)

                

        def on_click_btn_show_message(self, sender, args):
                MessageBox.Show("My message here")
               


                
        def on_click_btn_receive(self, sender, args):
            
                
                def on_eth_msg_received(msg):
                    print("Received following message from {0}".format(msg))
                
               
                ethernet_msg_1.on_message_received += on_eth_msg_received


                ethernet_msg_1.start_capture()
                

                sleep(15)


                ethernet_msg_1.stop_capture()


                ethernet_msg_1.on_message_received -= on_eth_msg_received
                

                

                


#----  MAIN  ----#

Application.Run(GUI_Dialog(250, 250))